class User < ApplicationRecord
  has_secure_password

  validates :username, presence: true

  validates :email, presence: true, uniqueness: true

  validates :password, length: { minimum: 8 }, if: -> { password.present? }

  before_validation :normalizar_email
end
